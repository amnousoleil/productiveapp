/**
 * Module Calendrier - Controller
 */
import { Request, Response } from 'express';
import * as svc from './calendar.service.js';

type Req = Request<{ workspaceId: string; id?: string }>;

export const list = async (req: Req, res: Response): Promise<void> => {
  try {
    if (!req.query.start_date || !req.query.end_date) { res.status(400).json({ error: 'start_date et end_date requis' }); return; }
    res.json(await svc.listEvents(req.params.workspaceId, { memberId: req.query.member_id as string, startDate: req.query.start_date as string, endDate: req.query.end_date as string, eventType: req.query.event_type as string }));
  } catch (e) { console.error('Calendar list:', e); res.status(500).json({ error: 'Erreur' }); }
};
export const get = async (req: Req, res: Response): Promise<void> => {
  try { const r = await svc.getEvent(req.params.workspaceId, req.params.id!); if (!r) { res.status(404).json({ error: 'Evenement non trouve' }); return; } res.json(r); } catch (e) { res.status(500).json({ error: 'Erreur' }); }
};
export const create = async (req: Req, res: Response): Promise<void> => {
  try {
    if (!req.body.title || !req.body.start_date) {
      res.status(400).json({ error: 'title et start_date requis' });
      return;
    }

    // FIX: Récupérer member_id de manière flexible (req.user > req.body > null)
    // Ne PAS retourner 401 si manquant, laisser le service gérer avec NULL
    const memberId = (req as any).user?.id || req.body.member_id || null;

    res.status(201).json(await svc.createEvent(req.params.workspaceId, memberId, req.body));
  } catch (e) {
    console.error('Calendar create:', e);
    res.status(500).json({ error: 'Erreur' });
  }
};
export const update = async (req: Req, res: Response): Promise<void> => {
  try { const r = await svc.updateEvent(req.params.workspaceId, req.params.id!, req.body); if (!r) { res.status(404).json({ error: 'Evenement non trouve' }); return; } res.json(r); } catch (e) { res.status(500).json({ error: 'Erreur' }); }
};
export const remove = async (req: Req, res: Response): Promise<void> => {
  try { const ok = await svc.deleteEvent(req.params.workspaceId, req.params.id!); if (!ok) { res.status(404).json({ error: 'Evenement non trouve' }); return; } res.status(204).send(); } catch (e) { res.status(500).json({ error: 'Erreur' }); }
};
export const upcoming = async (req: Req, res: Response): Promise<void> => {
  try { res.json(await svc.getUpcoming(req.params.workspaceId, req.query.member_id as string || '', parseInt(req.query.days as string) || 7)); } catch (e) { res.status(500).json({ error: 'Erreur' }); }
};
export const syncTasks = async (req: Req, res: Response): Promise<void> => {
  try { res.json(await svc.syncTaskDeadlines(req.params.workspaceId)); } catch (e) { console.error('Calendar sync tasks:', e); res.status(500).json({ error: 'Erreur' }); }
};
export const syncInvoices = async (req: Req, res: Response): Promise<void> => {
  try { res.json(await svc.syncInvoiceDueDates(req.params.workspaceId)); } catch (e) { console.error('Calendar sync invoices:', e); res.status(500).json({ error: 'Erreur' }); }
};
